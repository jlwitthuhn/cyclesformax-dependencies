#pragma once

/**
 * @file
 * @brief Defines NodeId.
 */

#include <cstdint>

namespace csg {
	typedef int64_t NodeId;
}
