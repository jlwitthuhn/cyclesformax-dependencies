#include "wrapper_glfw_func.h"

// All functions are defined inline in the header
// All that is needed here is the global glfw mutex

std::mutex glfw_global_mutex;
