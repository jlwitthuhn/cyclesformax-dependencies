# Code Samples of oneAPI Threading Building Blocks (oneTBB)
Examples using `task_group` interface.

| Code sample name | Description
|:--- |:---
| sudoku | Compute all solutions for a Sudoku board.
